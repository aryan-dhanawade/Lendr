import { NextResponse } from "next/server"

const API_URL = "http://127.0.0.1:5000/get-risk" // Replace with your Flask API URL

export async function POST(request: Request) {
  const { id } = await request.json()

  if (!id) {
    return NextResponse.json({ error: "ID is required" }, { status: 400 })
  }

  try {
    // Make a POST request to the Flask API
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id }),
    })

    // Check if the Flask API returned an error
    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json({ error: errorData.error }, { status: response.status })
    }

    // Parse the response from the Flask API
    const riskAssessment = await response.json()
    return NextResponse.json(riskAssessment)
  } catch (error) {
    // Handle network or other unexpected errors
    return NextResponse.json({ error: "Failed to fetch data from the Flask API" }, { status: 500 })
  }
}

